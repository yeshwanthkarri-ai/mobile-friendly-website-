# 📱 Mobile-Friendly Website Using CSS Media Queries

A comprehensive demonstration and guide for converting an existing desktop-only website into a modern, mobile-friendly layout using **CSS Media Queries**, fluid layouts, and mobile-first principles.

---

## 🎯 Objective & Deliverables

- **Objective:** Convert an existing desktop-only page into a responsive, mobile-friendly layout.
- **Tools:** HTML5, CSS3, JavaScript (vanilla), VS Code, and Chrome DevTools.
- **Deliverables:**
  - `before_desktop.html` & `before_style.css`: Baseline desktop-only website showing common mobile failure points (horizontal scroll, fixed 1200px container, missing viewport meta tag, un-clickable tap targets).
  - `index.html`: Optimized semantic HTML5 page with viewport meta tag and accessible mobile navigation.
  - `style.css`: Clean, modular CSS featuring structured Media Queries across all major device breakpoints (`1024px`, `768px`, and `480px`).
  - `script.js`: Accessible mobile navigation toggle with backdrop handling and ARIA state management.

---

## 📂 Project Structure

```text
mobile-friendly-website/
│
├── index.html            # [AFTER] Fully responsive, mobile-friendly website
├── style.css             # [AFTER] Responsive CSS with Media Queries & fluid layout
├── script.js             # Mobile drawer toggle & interactive behavior
│
├── before_desktop.html   # [BEFORE] Desktop-only baseline version (fixed 1200px)
├── before_style.css      # [BEFORE] Desktop-only stylesheet (no media queries)
│
└── README.md             # Detailed guide and DevTools testing instructions
```

---

## 🔍 Key Differences: Desktop-Only vs. Mobile-Friendly

| Feature | Desktop-Only (`before_style.css`) | Mobile-Friendly (`style.css`) |
| :--- | :--- | :--- |
| **Viewport Meta Tag** | ❌ Missing or ignored | ✅ `<meta name="viewport" content="width=device-width, initial-scale=1.0">` |
| **Container Width** | ❌ Fixed `width: 1200px;` (forces horizontal scroll) | ✅ Fluid `width: 100%; max-width: 1200px; padding: 0 24px;` |
| **Navigation** | ❌ Rigid horizontal bar that overflows screen | ✅ Collapsible hamburger drawer menu with smooth slide-in |
| **Grid / Layout** | ❌ Hardcoded multi-columns (`width: 780px`, `360px`) | ✅ Fluid CSS Grid & Flexbox columns stacking vertically on mobile |
| **Media Queries** | ❌ None | ✅ Organized breakpoints: `@media (max-width: 768px)` and `@media (max-width: 480px)` |
| **Images & Media** | ❌ Fixed pixel widths | ✅ Fluid `max-width: 100%; height: auto;` |
| **Tap Targets** | ❌ Small links (~16px), hard to tap with thumbs | ✅ Touch-friendly buttons & links (min 44px &times; 44px height/width) |
| **Tables** | ❌ Fixed widths causing layout blowout | ✅ Contained in `.table-responsive` with swipe hint & momentum scrolling |

---

## 🛠️ How CSS Media Queries Work in This Project

Media queries apply specific CSS rules only when the browser viewport matches designated criteria (e.g., screen width, device orientation, or user accessibility settings).

### 1. Viewport Meta Tag (Mandatory Foundation)
```html
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```
> **Why it's essential:** Mobile browsers default to simulating a 980px desktop screen and zooming out, making text microscopic. This tag forces the viewport to match the device's physical screen width at a 1:1 scale.

---

### 2. Tablet Portrait & Mobile Breakpoint (`max-width: 768px`)
Transforms the desktop multi-column structure into an intuitive vertical stack:

```css
@media (max-width: 768px) {
  /* 1. Reveal mobile hamburger button */
  .hamburger-btn {
    display: flex;
  }

  /* 2. Transform navigation bar into slide-out drawer */
  .nav {
    position: fixed;
    top: 0;
    right: -100%;
    width: 280px;
    height: 100vh;
    background: #ffffff;
    transition: right 0.3s ease;
  }

  .nav.is-open {
    right: 0;
  }

  /* 3. Stack Hero Section */
  .hero-container {
    flex-direction: column;
    text-align: center;
  }

  /* 4. Convert Main + Sidebar columns to full width */
  .main-layout {
    flex-direction: column;
  }

  .main-column,
  .sidebar {
    width: 100%;
  }

  /* 5. Contact form inputs stack */
  .form-row {
    grid-template-columns: 1fr;
  }
}
```

---

### 3. Small Smartphones Breakpoint (`max-width: 480px`)
Fine-tunes the interface for compact screens (such as 320px–390px phones):

```css
@media (max-width: 480px) {
  /* Maximize screen real estate by reducing outer padding */
  .container {
    padding-left: 16px;
    padding-right: 16px;
  }

  /* Fluid typography: scale down large headings */
  .hero-title {
    font-size: 1.85rem;
  }

  /* Full-width stacked action buttons for easy thumb-tapping */
  .hero-actions {
    flex-direction: column;
    width: 100%;
  }

  .hero-actions .btn {
    width: 100%;
  }

  /* Single-column services */
  .services-grid {
    grid-template-columns: 1fr;
  }
}
```

---

## 🧪 Testing with Chrome DevTools (Step-by-Step)

Chrome DevTools provides a built-in device emulator to test how your responsive layout responds to different devices.

### Step 1: Open Chrome DevTools
1. Double-click `index.html` (or right-click and choose **Open with > Google Chrome**).
2. Press `F12` (or right-click anywhere on the page and select **Inspect**, or press `Ctrl + Shift + I`).

### Step 2: Activate Device Mode
1. Click the **Toggle device toolbar** icon (top-left of DevTools) or press `Ctrl + Shift + M`.
2. A responsive viewport frame appears around the web page.

### Step 3: Test Device Presets
1. In the top toolbar dropdown menu, select different devices:
   - **iPhone 14 / 15 / 16 Pro** (390 &times; 844 px)
   - **Pixel 7** (412 &times; 915 px)
   - **Samsung Galaxy S20 Ultra** (412 &times; 915 px)
   - **iPad Air** (820 &times; 1180 px)
2. Verify that:
   - No horizontal scrollbar appears.
   - The hamburger menu opens and closes smoothly.
   - Text remains clear and legible without zooming.
   - Buttons span full width and are comfortable to tap.
   - The comparison table scrolls horizontally inside its container.

### Step 4: Test Fluid Resizing
1. Select **Responsive** in the device dropdown.
2. Drag the right edge handle from **1400px** down to **320px**.
3. Watch the elements dynamically rearrange as each media query breakpoint (`1024px`, `768px`, `480px`) is crossed.

### Step 5: Compare with `before_desktop.html`
1. Open `before_desktop.html` in Chrome DevTools Device Mode.
2. Notice the severe layout breaks:
   - Text is either microscopic or elements run far off-screen.
   - Horizontal scrollbar appears.
   - Navigation links are cramped or cut off.

---

## 💻 Working in Visual Studio Code (VS Code)

1. Open the folder in VS Code:
   ```powershell
   code "c:\Users\ADMIN\Downloads\mobile friendly website"
   ```
2. Install the **Live Server** extension (by Ritwick Dey) if available:
   - Right-click `index.html` &rarr; **Open with Live Server**.
   - Changes saved in `style.css` will instantly hot-reload in Chrome.
3. Open `style.css` side-by-side with `index.html` using `Ctrl + \` to inspect class names while adjusting media queries.

---

## 🏆 Summary of Mobile-Friendly Best Practices

1. **Mobile-First or Graceful Degradation:** Use fluid grids and percentage widths instead of fixed pixels (`px`).
2. **Standard Breakpoints:**
   - Mobile: `< 480px`
   - Tablet: `481px – 768px`
   - Laptop / Small Desktop: `769px – 1024px`
   - Large Desktop: `> 1024px`
3. **Touch Targets:** Maintain at least `44px × 44px` for interactive buttons and navigation links.
4. **Accessible Navigation:** Use a hamburger button with ARIA attributes (`aria-expanded`, `aria-controls`) and backdrop dismiss.
5. **Horizontal Overflow Prevention:** Keep `max-width: 100%` on images and media, and use `overflow-x: hidden` on body or `overflow-x: auto` on tables.
