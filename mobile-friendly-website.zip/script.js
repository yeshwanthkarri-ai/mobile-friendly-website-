/**
 * ApexStudio - Mobile Navigation & UI Interactions
 * Provides accessible mobile navigation drawer toggle, smooth closing,
 * backdrop overlay handling, and scroll-to-top button.
 */

document.addEventListener('DOMContentLoaded', () => {
  const hamburgerBtn = document.getElementById('hamburgerBtn');
  const primaryNav = document.getElementById('primaryNav');
  const mobileOverlay = document.getElementById('mobileOverlay');
  const navLinks = document.querySelectorAll('.nav-link');
  const backToTopBtn = document.getElementById('backToTop');

  // Helper: Open Mobile Nav
  const openMenu = () => {
    hamburgerBtn.classList.add('is-active');
    hamburgerBtn.setAttribute('aria-expanded', 'true');
    primaryNav.classList.add('is-open');
    mobileOverlay.classList.add('is-active');
    document.body.style.overflow = 'hidden'; // Lock background scrolling
  };

  // Helper: Close Mobile Nav
  const closeMenu = () => {
    hamburgerBtn.classList.remove('is-active');
    hamburgerBtn.setAttribute('aria-expanded', 'false');
    primaryNav.classList.remove('is-open');
    mobileOverlay.classList.remove('is-active');
    document.body.style.overflow = ''; // Unlock background scrolling
  };

  // Toggle button click
  if (hamburgerBtn) {
    hamburgerBtn.addEventListener('click', () => {
      const isExpanded = hamburgerBtn.getAttribute('aria-expanded') === 'true';
      if (isExpanded) {
        closeMenu();
      } else {
        openMenu();
      }
    });
  }

  // Backdrop overlay click
  if (mobileOverlay) {
    mobileOverlay.addEventListener('click', closeMenu);
  }

  // Close menu when clicking on any navigation link
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      if (window.innerWidth <= 768) {
        closeMenu();
      }
    });
  });

  // Close menu on pressing Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && primaryNav.classList.contains('is-open')) {
      closeMenu();
      hamburgerBtn.focus();
    }
  });

  // Handle window resize: automatically close drawer if resized to desktop
  window.addEventListener('resize', () => {
    if (window.innerWidth > 768 && primaryNav.classList.contains('is-open')) {
      closeMenu();
    }
  });

  // Back to Top button visibility on scroll
  if (backToTopBtn) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 400) {
        backToTopBtn.classList.add('is-visible');
      } else {
        backToTopBtn.classList.remove('is-visible');
      }
    });
  }
});
